import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

class LoginFields_inner implements ActionListener {
	
	JTextField id, dataarea;
	JPasswordField password;
	JPanel panel;
	public LoginFields_inner(JTextField id, JPasswordField password, JTextField dataarea) {
		this.id = id;
		this.password = password;
		this.dataarea = dataarea;
	}
	public LoginFields_inner(JTextField id, JPasswordField password, JTextField dataarea, JPanel panel) {
		this.id = id;
		this.password = password;
		this.dataarea = dataarea;
		this.panel = panel;
	}
			public void actionPerformed(ActionEvent e) {
			
			JButton button = (JButton) e.getSource();
			//if (e.getSource()==summit) {
				
			if (button.getText()=="Ȯ��") {
						  
			if(id.getText().length()==0 || password.getText().length()==0) {  // password�� getText ���� �ִ��� �Ⱦ��� ���ڴ� �ǹ� /����� ���̸� �ȵǴϱ�
				dataarea.setText("���̵�� ��й�ȣ�� �Է��ϼ���");
				panel.setBackground(Color.CYAN);
			}
			else {
				dataarea.setText("ID:"+id.getText()+"PASS:"+password.getText());
				panel.setBackground(Color.yellow);
			}
			}
			else {
					id.setText("");
					password.setText("");
					dataarea.setText("");
					panel.setBackground(Color.ORANGE);
				}
			}
		}		