import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

class ActionEventEx extends JFrame implements ActionListener {
	
	
		JPanel panel;
		JButton btn1, btn2;
		
		ActionEventEx() {
					
		panel = new JPanel();
		btn1 = new JButton ("�����");
		btn2 = new JButton ("��ũ��");
		
		btn1.addActionListener(this);
		btn2.addActionListener(this);
		
		panel.add(btn1);
		panel.add(btn2);	
		
		this.add(panel);
		
		// �׻� ���� �������ٰ�
		this.setTitle("�̺�Ʈ ����");
		this.setSize(300,300);
		this.getDefaultCloseOperation();
		this.setVisible(true);
	}
	
	public void  actionPerformed(ActionEvent e) {
		
		JButton button = (JButton) e.getSource();
	
		if (e.getSource() == btn1) {
				panel.setBackground(Color.YELLOW);
			}
			else if (e.getSource() == btn2) {
				panel.setBackground(Color.pink);
			}
		}
			
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ActionEventEx();
	}
}


		
	
