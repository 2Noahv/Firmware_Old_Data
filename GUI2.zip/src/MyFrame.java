import javax.swing.JButton;
import javax.swing.JFrame;

public class MyFrame extends JFrame {

	public MyFrame()
		//JFrame jf = new JFrame();
	
		JButton button = new JButton("��ư ����");
		this.add(button);

		//����
		setTitle("���� ����");
		setSize(500,500);
		
		//�ʼ�
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true); 
	}

	public static void main(String[] args) {
		
		new MyFrame();
	}
}
