import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;


	// �͸� Ŭ���� ó�����

	public class LoginFields_noName2 extends JFrame {

		public LoginFields_noName2() throws ParseException {  
		
		JPanel panel_c, panel_b, backpanel;
		JLabel label1, label2, label3;
		JTextField id, dataarea;
		JPasswordField password;
		JFormattedTextField data;
		JButton summit, cancel;
		
		
		summit = new JButton("Ȯ��");
		cancel = new JButton("���");
		label1 = new JLabel("���̵�", JLabel.CENTER);
		label2 = new JLabel("�н�����", JLabel.CENTER);
		label3 = new JLabel("�������", JLabel.CENTER);
					
		id=new JTextField(10);
		dataarea=new JTextField(20);
		password=new JPasswordField(10);
		MaskFormatter mf=new MaskFormatter("####-##-##   ");
		data=new JFormattedTextField(mf);
		
		panel_c = new JPanel();
		panel_b = new JPanel();
		backpanel = new JPanel();
		
		backpanel.setLayout(new GridLayout(0,2, 10, 10));
		
		backpanel.add(label1);
		backpanel.add(id);
		backpanel.add(label2);
		backpanel.add(password);
		backpanel.add(label3);
		backpanel.add(data);
		panel_c.add(summit);
		panel_c.add(cancel);
		
		summit.addActionListener(handler); 
		cancel.addActionListener(handler);
		
		panel_b.add(dataarea);
		
		this.add("North", backpanel);
		this.add("Center", panel_c);
		this.add("South", panel_b);	
		this.setSize(300, 200);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);			
		
		this.setVisible(true);
	
		}
		
			private ActionListener handler = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JButton button = (JButton) e.getSource();
					if (button.getText()=="Ȯ��") {
						
				if(id.getText().length()==0 || password.getText().length()==0)
					dataarea.setText("���̵�� ��й�ȣ�� �Է��ϼ���");
				else
					dataarea.setText("ID:"+id.getText()+"PASS:"+password.getText());
				}
				else {
					id.setText("");
					password.setText("");
					dataaarea.setText("");
					}		  
				}
			}; // ���� �� �� = class�� �ƴϹǷ� Syntax ����ǥ�� �� ��

		public static void main(String[] args) throws ParseException {
			new  LoginFields_noName2();
		}
	}	
			