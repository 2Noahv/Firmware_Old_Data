import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

	// �͸� Ŭ���� ó�����

	public class LoginFields_noName extends JFrame {

		public LoginFields_noName() throws ParseException {  // �̿��ؼ� 
		
		JPanel panel_c, panel_b, backpanel;
		JLabel label1, label2, label3;
		JTextField id, dataarea;
		JPasswordField password;
		JFormattedTextField data;
		JButton summit, cancel;
		
		
		summit = new JButton("Ȯ��");
		cancel = new JButton("���");
		label1 = new JLabel("���̵�", JLabel.CENTER);
		label2 = new JLabel("�н�����", JLabel.CENTER);
		label3 = new JLabel("�������", JLabel.CENTER);
					
		id=new JTextField(10);
		dataarea=new JTextField(20);
		password=new JPasswordField(10);
		MaskFormatter mf=new MaskFormatter("####-##-##   ");
		data=new JFormattedTextField(mf);
		
		panel_c = new JPanel();
		panel_b = new JPanel();
		backpanel = new JPanel();
		
		backpanel.setLayout(new GridLayout(0,2, 10, 10));
		
		backpanel.add(label1);
		backpanel.add(id);
		backpanel.add(label2);
		backpanel.add(password);
		backpanel.add(label3);
		backpanel.add(data);
		panel_c.add(summit);
		panel_c.add(cancel);
		
		
		summit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(id.getText().length()==0 || password.getText().length()==0) 
					dataarea.setText("���̵�� ��й�ȣ�� �Է��ϼ���");
				else
					dataarea.setText("ID:"+id.getText()+"PASS:"+password.getText());
			}	
		});
		
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				id.setText("");
				password.setText("");
				dataarea.setText("");
			}
		});
		
		panel_b.add(dataarea);
		
				
		this.add("North", backpanel);
		this.add("Center", panel_c);
		this.add("South", panel_b);	
				
		setSize(300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);			
		setVisible(true);
		}

		public static void main(String[] args) throws ParseException {
			LoginFields_innerClass classEvent = new LoginFields_innerClass();
		
		}
	}	
			