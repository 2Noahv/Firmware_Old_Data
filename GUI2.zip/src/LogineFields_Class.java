import java.awt.*;
import java.awt.event.*;
import java.text.ParseException;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
			
			
	//�ܺ� Ŭ���� ó�� ���
	//1. 
	//2. 
	//3. 
	
	public class LogineFields_Class extends JFrame{ 
				
		JPanel panel_c, panel_b, backpanel;
		JLabel label1, label2, label3;
		JTextField id, dataarea;
		JPasswordField password;
		JFormattedTextField data;
		JButton summit, cancel;
				
		
	
	public LogineFields_Class() throws ParseException {  
				
		summit = new JButton("Ȯ��");
		cancel = new JButton("���");
		label1 = new JLabel("���̵�", JLabel.CENTER);
		label2 = new JLabel("�н�����", JLabel.CENTER);
		label3 = new JLabel("�������", JLabel.CENTER);
							
		id=new JTextField(10);
		dataarea=new JTextField(20);
		password=new JPasswordField(10);
		MaskFormatter mf=new MaskFormatter("####-##-##   ");
		data=new JFormattedTextField(mf);
				
		panel_c = new JPanel();
		panel_b = new JPanel();
		backpanel = new JPanel();
				
		backpanel.setLayout(new GridLayout(0,2, 10, 10));
				
		backpanel.add(label1);
		backpanel.add(id);
		backpanel.add(label2);
		backpanel.add(password);
		backpanel.add(label3);
		backpanel.add(data);
				
		panel_c.add(summit);
		panel_c.add(cancel);
		panel_b.add(dataarea);
		
		
		//���� Ŭ����(new �ܺ� Ŭ����(������ ȣ��))
		//MyListener mylistener = new MyListener();
		summit.addActionListener(new LoginFields_inner(id, password, dataarea , panel_b)); 
		cancel.addActionListener(new LoginFields_inner(id, password, dataarea, panel_b));
				
		this.add("North", backpanel);
		this.add("Center", panel_c);
		this.add("South", panel_b);	
				
		setSize(300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);			
		setVisible(true);
				
	}
				
		
		public static void main(String[] args) throws ParseException {
			new LogineFields_Class();
		}
	}
